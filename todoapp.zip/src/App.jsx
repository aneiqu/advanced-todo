function App() {
  return (
    <>
      <div className='w-screen h-screen bg-gradient-to-tr from-slate-800 to-slate-900'></div>
    </>
  );
}

export default App;
